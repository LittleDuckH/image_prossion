'''
Author: huang
Date: 2023-12-25 17:59:24
LastEditors: Do not edit
LastEditTime: 2024-01-02 21:19:38
FilePath: \SRGAN\srgan.py
'''


from __future__ import print_function, division
from keras.layers import *
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.convolutional import UpSampling2D, Conv2D
from keras.applications import VGG19
from keras.models import Model
from keras.optimizers import Adam
import datetime
import matplotlib.pyplot as plt
from data_loader import DataLoader
import numpy as np
import os
from skimage.metrics import structural_similarity as ssim

def ssim_index(y_true, y_pred):
    return ssim(y_true, y_pred, multichannel=True)

def mae(y_true, y_pred):
    return K.mean(K.abs(y_pred - y_true))

def psnr(y_true, y_pred):
    max_pixel = 1.0
    return 20 * np.log10(max_pixel / np.sqrt(np.mean(np.square(y_pred - y_true))))

d_loss = []
g_loss = []

class SRGAN():
    def __init__(self):
        # 输入
        self.channels = 3
        self.lr_height = 64  # Low resolution height
        self.lr_width = 64  # Low resolution width
        self.lr_shape = (self.lr_height, self.lr_width, self.channels)
        self.hr_height = self.lr_height * 4  # High resolution height
        self.hr_width = self.lr_width * 4  # High resolution width
        self.hr_shape = (self.hr_height, self.hr_width, self.channels)

        # 添加 PSNR 和 SSIM 的记录列表
        self.psnr_values = []
        self.ssim_values = []

        # 添加损失记录列表
        self.d_losses = []
        self.g_losses = []

        # 生成器的残差块
        self.n_residual_blocks = 16

        # 学习率、指数衰减率
        optimizer = Adam(0.0002, 0.5)
        self.vgg = self.build_vgg()
        self.vgg.trainable = False

        # 打印出 VGG 模型的每一层的名称、输出形状、以及参数数量
        self.vgg.summary()
        # 代码编译模型，指定了损失函数、损失权重和优化器
        self.vgg.compile(loss='mse',
                         optimizer=optimizer,
                         metrics=['accuracy'])

        # 下载数据集
        self.dataset_name = 'D:/desktop/z1/zz1/SRGAN/img_align_celeba'
        self.data_loader = DataLoader(dataset_name=self.dataset_name,
                                      img_res=(self.hr_height, self.hr_width))

        # 判别器的图片大小
        patch = int(self.hr_height / 2 ** 4)
        self.disc_patch = (patch, patch, 1)

        # 生成器和判别器滤波器数量
        self.gf = 64
        self.df = 64

        # 构建并编译判别器
        self.discriminator = self.build_discriminator()
        self.discriminator.compile(loss='mse',
                                   optimizer=optimizer,
                                   metrics=['accuracy'])
        self.discriminator.summary()

        # 构建生成器
        self.generator = self.build_generator()

        # 高分辨率和低分辨率图片
        img_hr = Input(shape=self.hr_shape)
        img_lr = Input(shape=self.lr_shape)

        fake_hr = self.generator(img_lr)

        # 提取生成图像特征
        fake_features = self.vgg(fake_hr)

        # 只训练生成器
        self.discriminator.trainable = False

        # 判别器确定生成的高分辨率图像
        validity = self.discriminator(fake_hr)

        self.combined = Model([img_lr, img_hr], [validity, fake_features])
        self.combined.summary()
        self.combined.compile(loss=['binary_crossentropy', 'mse'],
                              loss_weights=[1e-3, 1],
                              optimizer=optimizer)

    # 构建vgg模型
    def build_vgg(self):
        # print('start loading trianed weights of vgg...')
        vgg = VGG19(weights="imagenet")
        print('loading completes')
        vgg.outputs = [vgg.layers[9].output]

        img = Input(shape=self.hr_shape)
        img_features = vgg(img) # 获取图像的特征

        return Model(img, img_features)

    def build_generator(self):
        
        # 残差块
        def residual_block(layer_input, filters):
            # 'same'（即输出大小等于输入大小）， filters指定滤波器
            d = Conv2D(filters, kernel_size=3, strides=1, padding='same')(layer_input)
            d = Activation('relu')(d)
            d = BatchNormalization(momentum=0.8)(d) # 归一化
            d = Conv2D(filters, kernel_size=3, strides=1, padding='same')(d)
            d = BatchNormalization(momentum=0.8)(d)
            d = Add()([d, layer_input]) # 残差连接，将卷积层的输出与残差块的输入相加
            return d

        # 上采样和卷积操作的组合
        def deconv2d(layer_input):
            u = UpSampling2D(size=2)(layer_input) # 上采样，将输入层的尺寸增加两倍
            u = Conv2D(256, kernel_size=3, strides=1, padding='same')(u)
            u = Activation('relu')(u)
            return u

        # 低分辨率图像输入
        img_lr = Input(shape=self.lr_shape)

        c1 = Conv2D(64, kernel_size=9, strides=1, padding='same')(img_lr)
        c1 = Activation('relu')(c1)

        # 残差块
        r = residual_block(c1, self.gf)
        for _ in range(self.n_residual_blocks - 1):
            r = residual_block(r, self.gf)

        c2 = Conv2D(64, kernel_size=3, strides=1, padding='same')(r)
        c2 = BatchNormalization(momentum=0.8)(c2)
        c2 = Add()([c2, c1])

        # 整合,两次上采样
        u1 = deconv2d(c2)
        u2 = deconv2d(u1)

        # 生成高分辨率输出
        gen_hr = Conv2D(self.channels, kernel_size=9, strides=1, padding='same', activation='tanh')(u2)

        return Model(img_lr, gen_hr)

    def build_discriminator(self):
        
        # 构建块
        def d_block(layer_input, filters, strides=1, bn=True):
            d = Conv2D(filters, kernel_size=3, strides=strides, padding='same')(layer_input)
            d = LeakyReLU(alpha=0.2)(d)
            if bn:
                d = BatchNormalization(momentum=0.8)(d)
            return d

        # 输入图像
        d0 = Input(shape=self.hr_shape)
        d1 = d_block(d0, self.df, bn=False)
        d2 = d_block(d1, self.df, strides=2)
        d3 = d_block(d2, self.df * 2)
        d4 = d_block(d3, self.df * 2, strides=2)
        d5 = d_block(d4, self.df * 4)
        d6 = d_block(d5, self.df * 4, strides=2)
        d7 = d_block(d6, self.df * 8)
        d8 = d_block(d7, self.df * 8, strides=2)

        d9 = Dense(self.df * 16)(d8) # 全连接层
        d10 = LeakyReLU(alpha=0.2)(d9)
        validity = Dense(1, activation='sigmoid')(d10) # 输出压缩到 0 和 1 之间。表示生成的图像是真实的还是假的概率

        return Model(d0, validity)

    def train(self, epochs, batch_size=1, sample_interval=5):
        start_time = datetime.datetime.now()
        
        for epoch in range(epochs):
            if epoch > 30:
                sample_interval = 10
            if epoch > 100:
                sample_interval = 50

            # 判别器训练

            # 样本图像及其相应的调理图像
            imgs_hr, imgs_lr = self.data_loader.load_data(batch_size)

            # 从低分辨率图像生成高分辨率
            fake_hr = self.generator.predict(imgs_lr)

            # 创建真实和假的标签
            valid = np.ones((batch_size,) + self.disc_patch)
            fake = np.zeros((batch_size,) + self.disc_patch)

            # 训练判别器 (original images = real / generated = Fake)
            d_loss_real = self.discriminator.train_on_batch(imgs_hr, valid)
            d_loss_fake = self.discriminator.train_on_batch(fake_hr, fake)
            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

            #生成器训练

            imgs_hr, imgs_lr = self.data_loader.load_data(batch_size)
            valid = np.ones((batch_size,) + self.disc_patch)

            # 使用预训练的VGG19模型
            image_features = self.vgg.predict(imgs_hr)

            # 训练
            g_loss = self.combined.train_on_batch([imgs_lr, imgs_hr], [valid, image_features])
            elapsed_time = datetime.datetime.now() - start_time
            print("%d time: %s" % (epoch, elapsed_time))
            # print("d_loss = ", d_loss)
            # print("g_loss = ", g_loss)
            # print("d_loss_all = ", sum(d_loss) / len(d_loss))
            # print("g_loss_all = ", sum(g_loss) / len(g_loss))
            

            # 规范化图像数据
            real_images = (imgs_hr + 1) / 2.0
            generated_images = (fake_hr + 1) / 2.0
            # 在每个 epoch 结束时评估
            psnr_val = psnr(real_images, generated_images)
            ssim_val = ssim_index(real_images, generated_images)
            self.psnr_values.append(psnr_val)
            self.ssim_values.append(ssim_val)
            # mae_val = mae(real_images, generated_images)

            # # 在 TensorFlow 会话中评估 MAE 值
            # with tf.compat.v1.Session() as sess:
            #     mae_val_result = sess.run(mae_val)

            print("Epoch: {}, PSNR: {}, SSIM: {}".format(epoch, psnr_val, ssim_val))

            # 记录损失
            self.d_losses.append(sum(d_loss) / len(d_loss))
            self.g_losses.append(sum(g_loss) / len(g_loss))

            if epoch % sample_interval == 0:
                self.sample_images_new(epoch)
            if epoch % 500 == 0 and epoch > 1:
                self.generator.save_weights('./saved_model/' + str(epoch) + '.h5')

            # 每个 epoch 结束时保存损失曲线图
            if epoch % sample_interval == 0:
                self.plot_loss(epoch)
            
            if epoch % sample_interval == 0:
                self.plot_metrics(epoch)
        
        # 训练结束后保存损失曲线图
        self.plot_loss(epochs)
        self.plot_metrics(epochs)

    # 使用训练出来的h5权重文件来进行生成结果图
    def test_images(self, batch_size=1):
        imgs_hr, imgs_lr = self.data_loader.load_data(batch_size, is_pred=True)
        os.makedirs('saved_model/', exist_ok=True)
        self.generator.load_weights('./saved_model/' + str(500) + '.h5')
        fake_hr = self.generator.predict(imgs_lr)
        r, c = imgs_hr.shape[0], 2

        # 将图像数据从 [-1, 1] 范围规范化到 [0, 1] 范围，以便于可视化。
        imgs_lr = 0.5 * imgs_lr + 0.5
        fake_hr = 0.5 * fake_hr + 0.5
        imgs_hr = 0.5 * imgs_hr + 0.5

        # 保存生成的图像和高分辨率原图
        titles = ['Low resolution input', 'Generated Super resolution']
        fig, axs = plt.subplots(r, c)
        for row in range(r):
            for col, image in enumerate([imgs_lr, fake_hr]):
                axs[row, col].imshow(image[row])
                axs[row, col].set_title(titles[col])
                axs[row, col].axis('off')
        fig.savefig("./h500_result_test.png")
        plt.close()

    # 保存图片
    def sample_images_new(self, epoch):
        os.makedirs('images/', exist_ok=True)
        imgs_hr, imgs_lr = self.data_loader.load_data(batch_size=1, is_testing=True, is_pred=True)
        fake_hr = self.generator.predict(imgs_lr)

        # 将图像数据从 [-1, 1] 范围规范化到 [0, 1] 范围，以便于可视化。 
        imgs_lr = 0.5 * imgs_lr + 0.5
        fake_hr = 0.5 * fake_hr + 0.5
        imgs_hr = 0.5 * imgs_hr + 0.5
        r, c = imgs_hr.shape[0], 3
        titles = ['Generated  epoch: ' + str(epoch), 'Original', 'Low']
        fig, axs = plt.subplots(r, c)

        for row in range(r):
            for col, image in enumerate([fake_hr, imgs_hr, imgs_lr]):
                axs[row, col].imshow(image[row])
                axs[row, col].set_title(titles[col])
                axs[row, col].axis('off')

        fig.savefig("images/%d.png" % (epoch))
        plt.close()

    # 保存loss值
    def plot_loss(self, epoch):
        plt.figure(figsize=(10, 5))
        plt.plot(self.d_losses, label="Discriminator Loss")
        plt.plot(self.g_losses, label="Generator Loss")

        # 找出并标注最低损失值
        min_d_loss = min(self.d_losses)
        min_g_loss = min(self.g_losses)
        plt.scatter(self.d_losses.index(min_d_loss), min_d_loss, color='red')
        plt.scatter(self.g_losses.index(min_g_loss), min_g_loss, color='green')
        plt.text(self.d_losses.index(min_d_loss), min_d_loss, f'{min_d_loss:.4f}', fontsize=8)
        plt.text(self.g_losses.index(min_g_loss), min_g_loss, f'{min_g_loss:.4f}', fontsize=8)


        plt.title("Loss Over Epochs")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.legend()
        plt.savefig(f"loss/loss_epoch_{epoch}.png")
        plt.close()
    
    def plot_metrics(self, epoch):
        # 绘制 PSNR 和 SSIM 曲线
        plt.figure(figsize=(10, 5))
        plt.plot(self.psnr_values, label="PSNR")
        plt.plot(self.ssim_values, label="SSIM")

        # 找出并标注最高的 PSNR 和 SSIM 值
        max_psnr = max(self.psnr_values)
        max_ssim = max(self.ssim_values)
        plt.scatter(self.psnr_values.index(max_psnr), max_psnr, color='red')
        plt.scatter(self.ssim_values.index(max_ssim), max_ssim, color='green')
        plt.text(self.psnr_values.index(max_psnr), max_psnr, f'{max_psnr:.4f}', fontsize=8)
        plt.text(self.ssim_values.index(max_ssim), max_ssim, f'{max_ssim:.4f}', fontsize=8)

        plt.title("PSNR and SSIM Over Epochs")
        plt.xlabel("Epoch")
        plt.ylabel("Value")
        plt.legend()

        plt.tight_layout()
        plt.savefig(f"metrics/metrics_epoch_{epoch}.png")
        plt.close()
if __name__ == '__main__':
    gan = SRGAN()
    gan.train(epochs=15, batch_size=10, sample_interval=2)
    # gan.test_images()
