'''
Author: huang
Date: 2023-12-25 17:59:24
LastEditors: Do not edit
LastEditTime: 2023-12-28 19:06:37
FilePath: \Easiest-SRGAN-demo-master\generate_GIF.py
'''
import os
import imageio

images = []
dir_name = r'images_test/'
images_name = [x for x in os.listdir(dir_name)]
images_name.sort(key=lambda x: int(x[:-4]))
images_name = [dir_name + x for x in images_name]
print(len(images_name))
images_name = images_name[0:30]
for i in images_name:
    images.append(imageio.imread(i))
imageio.mimsave('demo_test.gif', images, duration=0.3)
