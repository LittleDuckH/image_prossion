'''
Author: huang
Date: 2023-12-25 17:59:24
LastEditors: Do not edit
LastEditTime: 2023-12-29 10:43:56
FilePath: \SRGAN\data_loader.py
'''
import scipy
from glob import glob
import numpy as np
import matplotlib.pyplot as plt
import os
class DataLoader():
    def __init__(self, dataset_name, img_res=(128, 128)):
        self.dataset_name = dataset_name
        self.img_res = img_res
    
    def load_data(self, batch_size=1, is_testing=False, is_pred=False):
        data_type = "train" if not is_testing else "test"
        if is_pred:
            # batch_images = ['test_images/' + x for x in os.listdir('test_images/')]
            batch_images = ['new_image_test/' + x for x in os.listdir('new_image_test/')]
        else:
            path = glob('%s/*' % (self.dataset_name))
            batch_images = np.random.choice(path, size=batch_size)

        imgs_hr = []
        imgs_lr = []
        for img_path in batch_images:
            img = self.imread(img_path)

            h, w = self.img_res
            low_h, low_w = int(h / 4), int(w / 4)
            
            img_hr = scipy.misc.imresize(img, self.img_res)
            img_lr = scipy.misc.imresize(img, (low_h, low_w))

            print("img = ", len(img))
            # print("img_hr = ", img_hr.shape())
            # print("img_lr = ", img_lr.shape())
            
            if not is_testing and np.random.random() < 0.5:
                img_hr = np.fliplr(img_hr)
                img_lr = np.fliplr(img_lr)

            imgs_hr.append(img_hr)
            imgs_lr.append(img_lr)

        imgs_hr = np.array(imgs_hr) / 127.5 - 1.
        imgs_lr = np.array(imgs_lr) / 127.5 - 1.

        return imgs_hr, imgs_lr


    def imread(self, path):
        return scipy.misc.imread(path, mode='RGB').astype(np.float)
